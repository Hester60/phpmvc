<?php
    require_once '../app/bootstrap.php';

    // Init Core
    $init = new Core;