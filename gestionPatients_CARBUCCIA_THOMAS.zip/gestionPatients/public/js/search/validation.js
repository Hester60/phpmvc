$(function(){

    $('#search').on('keyup', checkIfEmpty);

});

/**
 * Si rien n'est tapé dans l'input, le bouton submit est désactivé
 */
function checkIfEmpty(){
    if ($('#search').val().length > 0){
        $('#submitSearch').attr('disabled', false);
    } else {
        $('#submitSearch').attr('disabled', true);
    }

}