const regexMail = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;


$(function () {
    $('#submitForm').on('click', validateForm);
});


function validateForm() {

    let lastname = validateLastname($('#lastname').val());
    let firstname = validateFirstname($('#firstname').val());
    let birthdate = validateBirthdate($('#birthdate').val());
    let phone = validatePhone($('#phone').val());
    let mail = validateEmail($('#mail').val());
    let dateHour = validateDate($('#dateHourInput').val());


    if (lastname && firstname && birthdate && phone && mail && dateHour){
        $('#patientAppointmentForm').submit();
    }


}

/**
 * Vérifie si un input est vide
 * @param inputName
 * @returns {boolean}
 */
function checkIfEmpty(inputName) {
    let input = $('#' + inputName);

    if (input.val() === '') {
        return false;
    } else {
        return true;
    }
}

/**
 * Valide l'adresse email en vérifiant si elle est vide et si elle correspond au regex
 * @param email
 * @returns {boolean}
 */
function validateEmail(email) {

    if (!checkIfEmpty('mail')) {
        setError('mail');
        return false;
    }
    if (!regexMail.test(email)) {
        setError('mail', "L'adresse email n'est pas valide");
        return false;
    }
    setSuccess('mail');
    return true;

}

/**
 * Vérifie que le nom ne soit pas vide
 * @param lastname
 * @returns {boolean}
 */
function validateLastname(lastname) {
    if (!checkIfEmpty('lastname')) {
        setError('lastname');
        return false;
    }
    setSuccess('lastname');
    return true;

}

/**
 * Vérifie que le prénom ne soit pas vide
 * @param firstname
 * @returns {boolean}
 */
function validateFirstname(firstname) {
    if (!checkIfEmpty('firstname')) {
        setError('firstname');
        return false;
    }
    setSuccess('firstname');
    return true;
}

/**
 * Vérifie que la date de naissance ne soit pas vide
 * et qu'elle soit inférieur ou égale à la date d'aujourd'hui
 * @param birthdate
 * @returns {boolean}
 */
function validateBirthdate(birthdate) {

    if (!checkIfEmpty('birthdate')) {
        setError('birthdate');
        return false;
    }

    const currentDate = new Date();

    birthdate = birthdate.split('-');

    /** Comparaison de la date **/
    let errorMsg = "La date de naissance est supérieure à la date d'aujourd'hui";
    if (birthdate[0] > currentDate.getFullYear()) {
        setError('birthdate', errorMsg);
        return false;
    } else if (birthdate[0] == currentDate.getFullYear()){
        if (birthdate[1] > currentDate.getMonth() + 1) {
            setError('birthdate', errorMsg);
            return false;
        } else if (birthdate[1] == currentDate.getMonth() + 1){
            if (birthdate[2] > currentDate.getDate()){
                setError('birthdate', errorMsg);
                return false;
            }
        }
    }

    setSuccess('birthdate');
    return true;
}

/**
 * Vérifie que le numéro comporte bien 10 caractères (pas de regex)
 * @param phone
 * @returns {boolean}
 */
function validatePhone(phone){
    if (!checkIfEmpty('phone')) {
        setError('phone');
        return false;
    }
    if (phone.length !== 10){
        setError('phone', "Le numéro de téléphone doit comporter 10 chiffres");
        return false;
    }
    setSuccess('phone');
    return true;
}

/**
 * Vérifie que la date de naissance ne soit pas vide
 * et qu'elle soit inférieur ou égale à la date d'aujourd'hui
 * @returns {boolean}
 * @param dateHour
 */
function validateDate(dateHour) {
    console.log('validateDate()');

    if (!checkIfEmpty('dateHourInput')) {
        setError('dateHourInput');
        return false;
    }

    const currentDate = new Date();

    dateHour = dateHour.split(' ');
    let date = dateHour[0].split('/');



    /** Comparaison de la date **/
    let errorMsg = "La date du rendez-vous est dépassée";
    if (date[2] < currentDate.getFullYear()) {
        setError('dateHourInput', errorMsg);
        return false;
    } else if (date[2] == currentDate.getFullYear()){
        if (date[1] < currentDate.getMonth() + 1) {
            setError('dateHourInput', errorMsg);
            return false;
        } else if (date[1] == currentDate.getMonth() + 1){
            if (date[0] < currentDate.getDate()){
                setError('dateHourInput', errorMsg);
                return false;
            }
        }
    }

    setSuccess('dateHourInput');
    return true;
}

/**
 * Change la classe d'un input (error) et montre un message d'erreur
 * @param inputName
 * @param message
 */
function setError(inputName, message = "Ce champ est obligatoire") {
    let input = $('#' + inputName);

    input.removeClass('is-valid');
    input.addClass('is-invalid');
    $('#' + inputName + 'Error').text(message);
}

/**
 * Change la classe d'un input (success)
 * @param inputName
 */
function setSuccess(inputName) {
    let input = $('#' + inputName);

    input.removeClass('is-invalid');
    input.addClass('is-valid');
    $('#' + inputName + 'Error').text('');
}
