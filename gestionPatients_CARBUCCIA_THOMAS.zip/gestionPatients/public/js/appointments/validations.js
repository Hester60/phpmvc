$(function() {

    $(function () {
        $('#submitForm').on('click', validateForm);
    });

});

function validateForm() {


    let dateHour = validateDate($('#dateHourInput').val());
    let idPatients = validatePatient($('#idPatients').val());

    if (dateHour && idPatients){
        $('#appointmentForm').submit();
    }



}

/**
 * Vérifie si un input est vide
 * @param inputName
 * @returns {boolean}
 */
function checkIfEmpty(inputName) {
    let input = $('#' + inputName);

    if (input.val() === '') {
        return false;
    } else {
        return true;
    }
}

/**
 * Vérifie que la date de naissance ne soit pas vide
 * et qu'elle soit inférieur ou égale à la date d'aujourd'hui
 * @returns {boolean}
 * @param dateHour
 */
function validateDate(dateHour) {
    console.log('validateDate()');

    if (!checkIfEmpty('dateHourInput')) {
        setError('dateHourInput');
        return false;
    }

    const currentDate = new Date();

    dateHour = dateHour.split(' ');
    let date = dateHour[0].split('/');



    /** Comparaison de la date **/
    let errorMsg = "La date du rendez-vous est dépassée";
    if (date[2] < currentDate.getFullYear()) {
        setError('dateHourInput', errorMsg);
        return false;
    } else if (date[2] == currentDate.getFullYear()){
        if (date[1] < currentDate.getMonth() + 1) {
            setError('dateHourInput', errorMsg);
            return false;
        } else if (date[1] == currentDate.getMonth() + 1){
            if (date[0] < currentDate.getDate()){
                setError('dateHourInput', errorMsg);
                return false;
            }
        }
    }

    setSuccess('dateHourInput');
    return true;
}

function validatePatient(idPatients){
    if (!checkIfEmpty('idPatients')) {
        setError('dateHour');
        return false;
    }
    return true;
}

/**
 * Change la classe d'un input (error) et montre un message d'erreur
 * @param inputName
 * @param message
 */
function setError(inputName, message = "Ce champ est obligatoire") {
    console.log('setError()');

    let input = $('#' + inputName);

    input.removeClass('is-valid');
    input.addClass('is-invalid');
    $('#' + inputName + 'Error').text(message);
}

/**
 * Change la classe d'un input (success)
 * @param inputName
 */
function setSuccess(inputName) {
    let input = $('#' + inputName);

    input.removeClass('is-invalid');
    input.addClass('is-valid');
    $('#' + inputName + 'Error').text('');
}