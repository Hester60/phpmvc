<?php

class AppointmentForm
{

    private $dateHour;
    private $idPatients;
    private $errors = [];

    public function __construct($dateHour, $idPatients)
    {
        $this->dateHour = $dateHour;
        $this->idPatients = $idPatients;


    }

    public function validate()
    {
        $this->errors = [];


        $dateHour = $this->validateDate();
        $patient = $this->validatePatient();

        return $this->errors;
    }

    public function checkIfEmpty($val){
        if (empty($val)){
            return true;
        }
        return false;
    }

    /*
     * Vérifie que la date du rendez-vous n'est pas inférieure à la date d'aujourd'hui
     */
    public function validateDate(){

        if ($this->checkIfEmpty($this->dateHour)){
            array_push($this->errors, 'La date du rendez-vous est obligatoire');
            return false;
        }

        /**
         * Récupère uniquement la date
         */
        $date = explode(' ', $this->dateHour);
        $date = explode('/', $date[0]);

        $currentDate = date("d-m-Y");
        $currentDate = explode('-', $currentDate);
        $msgError = "La date du rendez-vous est dépassée";



        // Vérifie que l'année du rendez vous n'est pas inférieure à l'année actuelle
        if ($date[2] < $currentDate[2]) {
            array_push($this->errors, $msgError);
            return false;
        } else if ($date[2] == $currentDate[2]){
            // Vérifie que le mois du rendez vous n'est pas inférieur au mois actuel
            if ($date[1] < $currentDate[1]) {
                array_push($this->errors, $msgError);
                return false;
            } else if ($date[1] == $currentDate[1]){
                // Vérifie que le jour du rendez vous n'est pas inférieur au jour actuel
                if ($date[0] < $currentDate[0]){
                    array_push($this->errors, $msgError);
                    return false;
                }
            }
        }

        return true;
    }

    public function validatePatient(){
        // Vérifie que la valeur n'est pas vide
        if ($this->checkIfEmpty($this->idPatients)){
            array_push($this->errors, 'Le patient est obligatoire');
            return false;
        }

        return true;
    }

}