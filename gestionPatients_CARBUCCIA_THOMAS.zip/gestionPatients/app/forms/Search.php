<?php
    class SearchForm{

        private $terms;

        public function __construct($terms)
        {
            $this->terms = $terms;
        }

        // Vérifie que la valeur ne soit pas vide et bien de type string
        public function isValid(){
            if (empty($this->terms)){
                return false;
            }
            if (!is_string($this->terms)){
                return false;
            }

            return true;
        }
    }