<?php

    class PatientForm {
        private $lastname;
        private $firstname;
        private $birthdate;
        private $phone;
        private $mail;
        private $errors = [];

        public function __construct($lastname, $firstname, $birthdate, $phone, $mail)
        {
            $this->lastname = $lastname;
            $this->firstname = $firstname;
            $this->birthdate = $birthdate;
            $this->phone = $phone;
            $this->mail = $mail;
        }

        /** Vérifie que aucun champs n'est vide */
        public function validate()
        {
            $this->errors = [];

            $firstname = $this->validateFirstname($this->firstname);
            $lastname = $this->validateLastname($this->lastname);
            $birthdate = $this->validateBirthdate($this->birthdate);
            $phone = $this->validatePhone($this->phone);
            $mail = $this->validateEmail($this->mail);

            return $this->errors;
        }

        public function checkIfEmpty($val){
            if (empty($val)){
                return true;
            }
            return false;
        }

        // Vérifie que le format de l'email est valide
        public function validateEmail($email){
            if ($this->checkIfEmpty($email)){
                array_push($this->errors, 'L\'adresse email est obligatoire');
                return false;
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
                array_push($this->errors, "L'adresse email n'est pas valide");
                return false;
            }
            return true;
        }

        public function validateLastname($lastname){
            if ($this->checkIfEmpty($lastname)){
                array_push($this->errors, 'Le nom de famille est obligatoire');
                return false;
            }
            return true;
        }

        public function validateFirstname($firstname){
            if ($this->checkIfEmpty($firstname)){
                array_push($this->errors, 'Le prénom est obligatoire');
                return false;
            }
            return true;
        }

        // Vérifie que la date de naissance n'est pas supérieure à la date d'aujourd'hui
        public function validateBirthdate($birthdate){

            if ($this->checkIfEmpty($birthdate)){
                array_push($this->errors, 'La date de naissance est obligatoire');
                return false;
            }

            $currentDate = date("Y-m-d");
            $currentDate = explode('-', $currentDate);
            $birthdate = explode('-', $birthdate);
            $msgError = "La date de naissance est supérieure à la date d'aujourd'hui";

            if ($birthdate[0] > $currentDate[0]) {
                array_push($this->errors, $msgError);
                return false;
            } else if ($birthdate[0] == $currentDate[0]){
                if ($birthdate[1] > $currentDate[1]) {
                    array_push($this->errors, $msgError);
                    return false;
                } else if ($birthdate[1] == $currentDate[1]){
                    if ($birthdate[2] > $currentDate[2]){
                        array_push($this->errors, $msgError);
                        return false;
                    }
                }
            }

            return true;

        }

        /**
         * Vérifie uniquement si le numéro de téléphone comporte bien 10 caractères
         * @param $phone
         * @return bool
         */
        public function validatePhone($phone){
            if ($this->checkIfEmpty($phone)){
                array_push($this->errors, 'Le numéro de téléphone est obligatoire');
                return false;
            }

            if (strlen($phone) !== 10) {
                array_push($this->errors, "Le numéro de téléphone doit comporter 10 chiffres");
                return false;
            }
            return true;
        }





    }