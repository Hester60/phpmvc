<?php

function format_date_FrToMySQL($date){
    $formated_date = explode('/', $date);
    return $formated_date[2] . '-' . $formated_date[1] . '-' . $formated_date[0];
}

function format_date_MySQLToFr($date){
    $formated_date = explode('-', $date);
    return $formated_date[2] . '/' . $formated_date[1] . '/' . $formated_date[0];
}

function format_dateHour_frToMySQL($date){
    $dateArr = explode(' ', $date);
    $formatedDate = explode('/', $dateArr[0]);
    $dateHour = $formatedDate[2] . '-' . $formatedDate[1] . '-' . $formatedDate[0] . ' ' . $dateArr[1];

    return $dateHour;
}