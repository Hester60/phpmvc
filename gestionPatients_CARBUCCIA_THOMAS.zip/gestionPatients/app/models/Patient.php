<?php

class Patient
{
    private $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    // Récupère la liste des patients avec des paramètres pour la recherche et la pagination
    public function getPatientsWithPagination($lastname = null, $page = 0, $maxPatients = 2)
    {
        $offset = ($page * $maxPatients);
        if ($lastname !== null) {
            $this->db->query('SELECT *, DATE_FORMAT(birthdate, "%d/%m/%Y") as birthdate FROM patients WHERE lastname LIKE ? ORDER BY lastname LIMIT ? OFFSET ?');
            $this->db->bind(1, "%$lastname%");
            $this->db->bind(2, $maxPatients);
            $this->db->bind(3, $offset);
            $data['patients'] = $this->db->resultSet();

            $this->db->query('SELECT COUNT(*) as total FROM patients WHERE lastname LIKE ? ');
            $this->db->bind(1, "%$lastname%");
            $data['totalPatients'] = $this->db->resultSet();

            return $data;

        } else {
            $this->db->query('SELECT *, DATE_FORMAT(birthdate, "%d/%m/%Y") as birthdate FROM patients ORDER BY lastname LIMIT :maxPatients OFFSET :offset');
            $this->db->bind('maxPatients', $maxPatients);
            $this->db->bind('offset', $offset);
            $data['patients'] = $this->db->resultSet();

            $this->db->query('SELECT COUNT(*) as total FROM patients');
            $data['totalPatients'] = $this->db->resultSet();

            return $data;
        }
    }

    // Récupère simplement tous les patients sans paramètres
    public function getPatients(){
        $this->db->query('SELECT *, DATE_FORMAT(birthdate, "%d/%m/%Y") as birthdate FROM patients');
        return $this->db->resultSet();
    }

    // Récupère avec patient avec son ID
    public function getPatientById($id)
    {
        $this->db->query('SELECT *, DATE_FORMAT(birthdate, "%d/%m/%Y") as birthdate FROM patients WHERE id = :id');
        $this->db->bind('id', $id);

        $patient = $this->db->single();

        if ($this->db->rowCount() > 0) {
            return $patient;
        } else {
            return false;
        }
    }

    // Créer un patient
    public function create($formData){
        $this->db->query('INSERT INTO patients (lastname, firstname, birthdate, phone, mail) VALUES(:lastname, :firstname, :birthdate, :phone, :mail)');
        $this->db->bind('lastname', $formData['lastname']);
        $this->db->bind('firstname', $formData['firstname']);
        $this->db->bind('birthdate', $formData['birthdate']);
        $this->db->bind('phone', $formData['phone']);
        $this->db->bind('mail', $formData['mail']);

        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

    // Modifie un patient
    public function editPatient($data)
    {
        $this->db->query('UPDATE patients SET lastname = :lastname, firstname = :firstname, birthdate = :birthdate, phone = :phone, mail = :mail WHERE id = :id');
        $this->db->bind('id', $data['id']);
        $this->db->bind('lastname', $data['lastname']);
        $this->db->bind('firstname', $data['firstname']);
        $this->db->bind('birthdate', $data['birthdate']);
        $this->db->bind('phone', $data['phone']);
        $this->db->bind('mail', $data['mail']);

        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

    // Supprime un patient
    public function delete($id){
        $this->db->query('DELETE FROM appointments
        WHERE idPatients IN (
            SELECT id FROM patients WHERE id = :id
        );
        DELETE FROM patients
        WHERE id = :id');
        $this->db->bind('id', $id);

        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }
}