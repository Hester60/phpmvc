<?php

class Appointment
{

    private $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    // Enregistre un nouveau rendez-vous
    public function create($data)
    {


        $this->db->query('INSERT INTO appointments (dateHour, idPatients) VALUES(:dateHour, :idPatients)');
        $this->db->bind('dateHour', $data['dateHour']);
        $this->db->bind('idPatients', $data['idPatients']);


        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }



    // Récupère tous les rendez-vous (on format la date en français pour l'UI, et on récupère le patient associé)
    public function getAppointments()
    {
        $this->db->query('SELECT appointments.id, dateHour, patients.id as patientId, patients.lastname as patientLastname, patients.firstname as patientFirstname, 
            DATE_FORMAT(dateHour, "%d/%m/%Y %T") as dateHour FROM appointments 
            JOIN patients ON appointments.idPatients = patients.id GROUP BY appointments.id ORDER BY dateHour ASC');


        return $this->db->resultSet();

    }

    // Trouve un rendez-vous avec son id
    public function getAppointmentById($id)
    {
        $this->db->query('SELECT appointments.id, dateHour, patients.id as patientId, patients.lastname as patientLastname, patients.firstname as patientFirstname, 
            DATE_FORMAT(dateHour, "%d/%m/%Y %T") as dateHour FROM appointments 
            JOIN patients ON appointments.idPatients = patients.id WHERE appointments.id = :id ');
        $this->db->bind('id', $id);

        $patient = $this->db->single();


        if ($this->db->rowCount() > 0) {
            return $patient;
        } else {
            return false;
        }
    }

    // Modifie un rendez-vous
    public function editAppointments($data)
    {
        $this->db->query('UPDATE appointments SET dateHour = :dateHour, idPatients = :idPatients WHERE id = :id');
        $this->db->bind('id', $data['id']);
        $this->db->bind('dateHour', $data['dateHour']);
        $this->db->bind('idPatients', $data['idPatients']);


        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

    // Récupère les rendez-vous d'un patient
    public function getAppointmentsByPatientId($id)
    {

        $this->db->query('SELECT id, DATE_FORMAT(dateHour, "%d/%m/%Y %T") as dateHour FROM appointments WHERE idPatients = :id');
        $this->db->bind('id', $id);


        return $this->db->resultSet();

    }

    // Supprime un rendez-vous
    public function delete($id)
    {
        $this->db->query('DELETE FROM appointments WHERE id = :id');
        $this->db->bind('id', $id);

        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }
}