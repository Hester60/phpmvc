<?php

    class Patientappointment {
        private $db;

        public function __construct()
        {
            $this->db = new Database();
        }

        // Créer un patient
        public function create($formData){
            $this->db->query('INSERT INTO patients (lastname, firstname, birthdate, phone, mail) VALUES(:lastname, :firstname, :birthdate, :phone, :mail)');
            $this->db->bind('lastname', $formData['lastname']);
            $this->db->bind('firstname', $formData['firstname']);
            $this->db->bind('birthdate', $formData['birthdate']);
            $this->db->bind('phone', $formData['phone']);
            $this->db->bind('mail', $formData['mail']);

            if ($this->db->execute()) {
                $patient_id = $this->db->lastId();
                $this->db->query('INSERT INTO appointments (dateHour, idPatients) VALUES(:dateHour, :idPatients)');
                $this->db->bind('dateHour', $formData['dateHour']);
                $this->db->bind('idPatients', $patient_id);

                if ($this->db->execute()) {
                    return $patient_id;
                } else {
                    $this->db->query('DELETE FROM patients WHERE id = :id');
                    $this->db->bind('id', $patient_id);
                    $this->db->execute();
                    return false;
                }
            }
            return false;
        }
    }