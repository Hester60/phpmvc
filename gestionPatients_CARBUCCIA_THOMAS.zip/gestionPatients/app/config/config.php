<?php
    // Paramètres de la base de données
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'hospitale2n');

    // App Root pour récupérer des fichiers
    define('APPROOT', dirname(dirname(__FILE__)));
    // URL Root pour les liens dans les templates
    define('URLROOT', 'http://localhost/gestionPatients');
    // Nom du site
    define('SITENAME', 'Gestion patients & rendez-vous');