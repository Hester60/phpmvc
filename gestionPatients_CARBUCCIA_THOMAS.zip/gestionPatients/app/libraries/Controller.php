<?php

/*
 * Controller principal
 * Charge les models et les vues
 */

class Controller
{

    // Charge un model
    public function model($model)
    {
        // Require
        require_once '../app/models/' . $model . '.php';

        // Instancie le model
        return new $model();
    }

    // Charge une vue
    public function view($view, $data = [])
    {
        // Vérifie si la vue existe
        if (file_exists('../app/views/' . $view . '.php')) {
            require_once '../app/views/' . $view . '.php';
        } else {
            die('La vue n\'existe pas.');
        }
    }
}