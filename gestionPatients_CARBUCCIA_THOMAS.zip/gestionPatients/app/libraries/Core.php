<?php
/**
 * App Core Class
 * Créer les URL et charge le controller principal
 * Format des URL - /controller/method/params
 */

class Core
{
    protected $currentController = 'Pages';
    protected $currentMethod = 'index';
    protected $params = [];

    public function __construct()
    {
        //print_r($this->getUrl());
        $url = $this->getUrl();


        // Vérifie si un controller existe
        if (file_exists('../app/controllers/' . ucwords($url[0]) . '.php')) {
            // Si un fichier existe, on le stock
            $this->currentController = ucwords($url[0]);
            // On retire l'index 0 de URL
            unset($url[0]);
        }

        // On inclus le controller
        require_once '../app/controllers/' . $this->currentController . '.php';

        // On l'instancie
        $this->currentController = new $this->currentController;

        // Vérifie la deuxième partie de l'url
        if (isset($url[1])){
            // Vérifie si une méthode existe dans le controller
            if (method_exists($this->currentController, $url[1])){
                $this->currentMethod = $url[1];
                unset($url[1]);
            } else {
                $this->currentMethod = 'notfound';
            }
        }

        // Récupère les paramètres si il y en a
        $this->params = $url ? array_values($url) : [];

        // Appelle une callback avec le tableau des params
        call_user_func_array([$this->currentController, $this->currentMethod],
        $this->params);
    }

    public function getUrl()
    {
        if (isset($_GET['url'])) {
            $url = rtrim($_GET['url'], '/');
            $url = filter_var($url, FILTER_SANITIZE_URL);
            $url = explode('/', $url);
            return $url;
        }

    }
}