<?php
    class Pages extends Controller {



        public function __construct()
        {

        }

        public function index(){
            $data = [
                'pageTitle' => 'Accueil',
            ];

            $this->view('pages/index', $data);
        }

        public function notfound(){
            $data = [
                'pageTitle' => '404',
            ];

            $this->view('pages/404', $data);
        }

    }