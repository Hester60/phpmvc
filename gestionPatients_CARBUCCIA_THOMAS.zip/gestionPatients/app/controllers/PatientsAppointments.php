<?php

require_once APPROOT . '/forms/Appointment.php';
require_once APPROOT . '/forms/Patient.php';

    class PatientsAppointments extends Controller {

        private $patientAppointmentModel;

        public function __construct()
        {
            $this->patientAppointmentModel = $this->model('PatientAppointment');

        }

        public function index()
        {
           redirect('');
        }

        public function create(){

            $errors = [];

            $data = [
                'pageTitle' => 'Ajouter un patient et un rendez-vous',
                'form_errors' => $errors
            ];

            if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                $patientForm = new PatientForm(
                    $_POST['lastname'],
                    $_POST['firstname'],
                    $_POST['birthdate'],
                    $_POST['phone'],
                    $_POST['mail']
                );

                $appointmentForm = new AppointmentForm($_POST['dateHour'], '1');


                $errorsPatient = $patientForm->validate();
                $errorsAppointment = $appointmentForm->validate();


                $mergedErrors = array_merge($errorsPatient, $errorsAppointment);
                $errors = array_merge($errors, $mergedErrors);



                if (count($errors) <= 0) {

                    $formData = [
                        'lastname' => ucfirst(strtolower($_POST['lastname'])),
                        'firstname' => ucfirst(strtolower($_POST['firstname'])),
                        'birthdate' => $_POST['birthdate'],
                        'phone' => $_POST['phone'],
                        'mail' => strtolower($_POST['mail']),
                        'dateHour' => format_dateHour_frToMySQL($_POST['dateHour'])
                    ];

                    $patientId = $this->patientAppointmentModel->create($formData);
                    if ( $patientId !== false){
                        // Création d'un message flash
                        flash('create_patientAppointment_success', 'Le patient et le rendez-vous ont bien été ajoutés!');

                        // On redirige l'utiliasteur vers la liste des rendez-vous
                        redirect('patients/show/' . $patientId);
                    }


                } else {
                    // S'il y a des erreurs, on les affiches sur la vue

                    $data['form_errors'] = $errors;
                }



            }

            $this->view('patientsAppointments/create', $data);
        }

    }