<?php
require_once APPROOT . '/forms/Appointment.php';

class Appointments extends Controller
{
    private $appointmentModel;
    private $patientModel;


    public function __construct()
    {
        $this->appointmentModel = $this->model('Appointment');
        $this->patientModel = $this->model('Patient');
    }

    /**
     * Liste des rendez-vous
     */
    public function index()
    {
        //Récupère les rendez-vous
        $appointments = $this->appointmentModel->getAppointments();
        $pageTitle = "Liste des rendez-vous";

        $data = [
            'pageTitle' => $pageTitle,
            'appointments' => $appointments
        ];

        $this->view('appointments/list', $data);
    }

    /**
     * Ajout d'un nouveau rendez-vous
     */
    public function create()
    {
        $pageTitle = "Enregistrer un nouveau rendez-vous";

        // On charge la liste des patients pour alimenter le select
        $patients = $this->patientModel->getPatients();
        // On initialise les erreurs avec un tableau vide
        $errors = [];

        $data = [
            'pageTitle' => $pageTitle,
            'patients' => $patients,
            'form_errors' => $errors
        ];

        // Si le formulaire est soumis
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {


            // On créer une nouvelle instance de AppointmentForm
            $form = new AppointmentForm($_POST['dateHour'], $_POST['idPatients']);


            /**
             * Le formulaire est validé côté client, puis côté serveur. Cependant,
             * si la validation serveur échoue, le formulaire est réinitiliasé
             */
            $errors = $form->validate();

            // On vérifie s'il n'y a pas d'erreur
            if (count($errors) <= 0) {
                // On prépare les données nécessaires à l'ajout
                $formData = [
                    'dateHour' => format_dateHour_frToMySQL($_POST['dateHour']),
                    'idPatients' => $_POST['idPatients'],
                ];

                // On ajoute les données à la BDD
                $this->appointmentModel->create($formData);

                // Création d'un message flash
                flash('create_appointment_success', 'Le rendez-vous a été ajouté !');

                // On redirige l'utiliasteur vers la liste des rendez-vous
                redirect('appointments');
            } else {
                // S'il y a des erreurs, on les affiches sur la vue
                $data['form_errors'] = $errors;
            }
        }

        $this->view('appointments/create', $data);
    }

    /**
     * Affiche un rendez-vous et permet de le modifier
     */
    public function show($id){
        // On charge la liste des rendez-vous
        $appointment = $this->appointmentModel->getAppointmentById($id);

        if (!$appointment){
            redirect('pages/notfound');
        }

        // On charge la liste des patients afin d'alimenter le select en cas de modification
        $patients = $this->patientModel->getPatients();


        $pageTitle = "Rendez-vous de " . $appointment->patientLastname . ' ' . $appointment->patientFirstname;

        // On initialise les erreurs avec un tableau vide
        $errors = [];

        $data = [
            'pageTitle' => $pageTitle,
            'appointment' => $appointment,
            'patients' => $patients,
            'form_errors' => $errors
        ];

        // Si le formulaire est soumis
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            // On créer une nouvelle instance de AppointmentForm afin de valider les données
            $form = new AppointmentForm($_POST['dateHour'], $_POST['idPatients']);


            /**
             * Le formulaire est validé côté client, puis côté serveur. Cependant,
             * si la validation serveur échoue, le formulaire est réinitiliasé
             */
            $errors = $form->validate();

            // On vérifie s'il n'y a pas d'erreurs
            if (count($errors) <= 0) {

                // On prépare les données pour la modification
                $formData = [
                    'id' => $appointment->id,
                    'dateHour' => format_dateHour_frToMySQL($_POST['dateHour']),
                    'idPatients' => $_POST['idPatients'],
                ];

                // On envoit les nouvelles données à la BDD et on vérifie que tout c'est bien passé
                if ($this->appointmentModel->editAppointments($formData)){

                    // On récupère les nouvelles données afin de mettre à jour l'UI
                    $data['appointment'] = $this->appointmentModel->getAppointmentById($appointment->id);

                    // On créer un message flash de confirmation
                    flash('edit_appointment_success', 'Le rendez-vous a été modifié !');

                } else {
                    // Erreur serveur/BDD
                    die('Une erreur serveur est survenue. /models/Patients.php L145');
                }
            } else {
                // S'il y a des erreurs, on les affiche
                $data['form_errors'] = $errors;
            }
        }

        $this->view('appointments/show', $data);
    }

    /**
     * Supprime un rendez-vous
     */
    public function delete($id)
    {

        // On vérifie qu'un formulaire a bien été soumis
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // On supprime en BDD et on vérifie que tout c'est bien passé
            if ($this->appointmentModel->delete($id)) {
                flash('delete_appointment_success', 'Le rendez-vous a été supprimé !');
                redirect('appointments');
            } else {
                // Quelque chose c'est mal passé
                die('Une erreur est survenue pendant la suppression (/models/Appointment.php');
            }
        }

    }

}

