<?php

require_once APPROOT . '/forms/Patient.php';
require_once APPROOT . '/forms/Search.php';


class Patients extends Controller
{

    private $patientModel;
    private $appointmentModel;

    // Maximum de patients affichés par page
    private $maxPatients = 5;
    // Page actuelle affichée
    private $page = 0;

    public function __construct()
    {
        $this->patientModel = $this->model('Patient');
        $this->appointmentModel = $this->model('Appointment');
    }

    /**
     * Affiche la liste des patients
     */
    public function index()
    {

        // On initialise les patients avec un tableau vide
        $patients = [];

        // On initialise le résultat d'une recherche à null
        $lastname = null;

        $data = [
            'pageTitle' => 'Liste des patients',
            'searchTerms' => ''
        ];



        // On vérifie si une recherche a été effectuée. Sinon, $lastname restera à null
        if (isset($_GET['lastname']) && !empty($_GET['lastname'])) {
            $lastname = $_GET['lastname'];
            $data['searchTerms'] = $_GET['lastname'];
        }

        // On vérifie si une page a été demandé, sinon la page est 0
        if (isset($_GET['page']) && !empty($_GET['page'])){
            $this->page = (int) $_GET['page'];
        }

        // On demande à la BDD les patients avec les paramètres de rechercher (par défault:  null, 0, 5)
        $queryResult = $this->patientModel->getPatientsWithPagination($lastname, $this->page, $this->maxPatients);

        // FORMULAIRE DE RECHERCHE PAR NOM DE FAMILLE: On vérifie si le formulaire a été soumis
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            // On créer une nouvelle instance de SearchForm qui ne sert qu'à vérifie
            // que la valeur ne soit pas vide et qu'il s'agit bien d'un type String
            $form = new SearchForm($_POST['search']);
            if ($form->isValid()){
                // Si le formulaire est valide, on redirige l'utilisateur vers la liste
                redirect('patients?lastname=' . $_POST['search']);
            }
        }

        $data['patients'] = $queryResult['patients'];

        // On calcul le nombre de pages maximum pour désactivé le bouton suivant de l'UI
        $data['maxPage'] = ceil((int)$queryResult['totalPatients'][0]->total / (int)$this->maxPatients);
        // Pour l'UI (page précédente)
        $data['previousPage'] = (int)$this->page - 1;
        // Pour l'UI (page suivante)
        $data['nextPage'] = (int)$this->page + 1;
        // Affiche la page actuelle
        $data['currentPage'] = (int)$this->page + 1;

        $this->view('patients/list', $data);
    }


    /**
     * Ajoute un nouveau patient
     */
    public function create()
    {
        $pageTitle = "Ajouter un nouveau patient";
        // Initialisation des erreurs dans un tableau vide
        $errors = [];


        $data = [
            'pageTitle' => $pageTitle,
            'form_errors' => $errors
        ];

        // Si le formulaire a été soumis
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            // Instanciation de PatientForm pour la validation serveur (juste par sécurité)
            $form = new PatientForm(
                $_POST['lastname'],
                $_POST['firstname'],
                $_POST['birthdate'],
                $_POST['phone'],
                $_POST['mail']
            );

            /**
             * Le formulaire est validé côté client, puis côté serveur. Cependant,
             * si la validation serveur échoue, le formulaire est réinitiliasé
             */
            $errors = $form->validate();

            // s'il n'y a pas d'erreur
            if (count($errors) <= 0) {
                // Préparation des données
                $formData = [
                    'lastname' => ucfirst(strtolower($_POST['lastname'])),
                    'firstname' => ucfirst(strtolower($_POST['firstname'])),
                    'birthdate' => $_POST['birthdate'],
                    'phone' => $_POST['phone'],
                    'mail' => strtolower($_POST['mail'])
                ];
                // Créer le nouveau patient en BDD
                $this->patientModel->create($formData);

                flash('create_patient_success', 'Le patient a été ajouté !');
                // On redirige vers la liste des patients
                redirect('patients');
            } else {
                // S'il y a des erreurs, on les affiche
                $data['form_errors'] = $errors;
            }
        }
        $this->view('patients/create', $data);
    }

    /**
     * Affiche le profil d'un patient et permet de le modifier
     */
    public function show($id){
        // Récupère le patient en fonction de son ID
        $patient = $this->patientModel->getPatientById($id);

        if (!$patient){
            redirect('pages/notfound');
        }


        // Récupère ses rendez-vous
        $appointments = $this->appointmentModel->getAppointmentsByPatientId($patient->id);
        $pageTitle = "Profil de " . $patient->lastname . ' ' . $patient->firstname;
        $errors = [];

        $data = [
            'pageTitle' => $pageTitle,
            'patient' => $patient,
            'appointments' => $appointments,
            'form_errors' => $errors
        ];

        // Si le formulaire est soumis
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            // Instanciation de PatientForm pour la validation serveur (par sécurité)
            $form = new PatientForm(
                $_POST['lastname'],
                $_POST['firstname'],
                $_POST['birthdate'],
                $_POST['phone'],
                $_POST['mail']
            );

            /**
             * Le formulaire est validé côté client, puis côté serveur. Cependant,
             * si la validation serveur échoue, le formulaire est réinitiliasé
             */
            $errors = $form->validate();

            // S'il n'y a pas d'erreurs
            if (count($errors) <= 0) {

                // Préparation des données
                $formData = [
                    'id' => $patient->id,
                    'lastname' => ucfirst(strtolower($_POST['lastname'])),
                    'firstname' => ucfirst(strtolower($_POST['firstname'])),
                    'birthdate' => $_POST['birthdate'],
                    'phone' => $_POST['phone'],
                    'mail' => strtolower($_POST['mail'])
                ];

                // On modifie le patient en BDD et on vérifie que tout c'est bien passé
                if ($this->patientModel->editPatient($formData)){
                    // on récupère le patient pour mettre à jour l'UI
                    $data['patient'] = $this->patientModel->getPatientById($patient->id);
                    flash('edit_patient_success', 'Le patient a été modifié !');

                } else {
                    // Si la modification s'est mal passée
                    die('Une erreur serveur est survenue. /models/Patients.php ');
                }

            } else {
                // S'il y a des erreurs dans le formulaire on prévient l'utilisateur
                $data['form_errors'] = $errors;
            }
        }

        $this->view('patients/show', $data);
    }

    /**
     * Supprime un patient (et ses rendez-vous)
     */
    public function delete($id)
    {

        // On vérifie qu'un formulaire a bien été soumis
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // On supprime le patient dans la BDD et on vérifie que tout c'est bien passé
            if ($this->patientModel->delete($id)) {
                flash('delete_patient_success', 'Le patient a été supprimé !');
                redirect('patients');
            } else {
                // Erreur lors de la suppression en BDD
                die('Une erreur est survenue pendant la suppression (/models/Patient.php');
            }
        }

    }

}


