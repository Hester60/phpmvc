<?php require APPROOT . '/views/inc/header.php'; ?>

    <div class="jumbotron">
        <h1 class="display-4">Gestion Patients & Rendez-vous</h1>
        <p class="lead">Développé par Carbuccia Thomas</p>
        <hr class="my-4">
        <p>Que souhaitez-vous faire ?</p>
        <p class="lead d-flex flex-column">
        <div>
            <a href="<?= URLROOT ?>/patients/create"  class="btn btn-primary">Ajouter un nouveau
                patient</a>
        </div>

        <div class="mt-2">
            <a href="<?= URLROOT ?>/appointments/create" class="btn btn-primary">Enregistrer un nouveau
                rendez-vous</a>

        </div>
        <div class="mt-2">
            <a href="<?= URLROOT ?>/patientsAppointments/create" class="btn btn-primary">Enregistrer un patient et un rendez-vous simultanément</a>

        </div>

    </div>

<?php require APPROOT . '/views/inc/footer.php'; ?>