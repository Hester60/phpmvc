<?php require APPROOT . '/views/inc/header.php'; ?>

<div class="row py-5">
    <div class="col-md-10 mx-auto">
        <div class="card card-body">
            <div class="card-title">Ajouter un patient et un rendez-vous</div>
            <!-- Affichage des erreurs s'il y en a -->
            <?php if (isset($data['form_errors']) && count($data['form_errors']) > 0): ?>
                <div class="alert alert-danger">
                    <div class="formErrors">
                        <div>
                            <strong>L'ajout a échoué :</strong>
                        </div>
                        <?php foreach ($data['form_errors'] as $error): ?>

                            - <?= $error ?><br>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif ?>


            <form class="form" id="patientAppointmentForm" name="createPatientAppointment" method="POST" action="<?= URLROOT ?>/patientsappointments/create">
                <!-- LASTNAME -->
                <div class="form-group">
                    <label for="lastname">Nom</label>
                    <input type="text" class="form-control" name="lastname" id="lastname"
                           placeholder="Nom de famille">
                    <span class="invalid-feedback" id="lastnameError"></span>
                </div>
                <!-- FIRSTNAME -->
                <div class="form-group">
                    <label for="firstname">Prénom</label>
                    <input type="text" class="form-control" name="firstname"
                           id="firstname" placeholder="Prénom"
                    >
                    <span class="invalid-feedback" id="firstnameError"></span>
                </div>
                <!-- BIRTHDATE -->
                <div class="form-group">
                    <label for="birthdate">Date de naissance</label>
                    <input type="date" class="form-control" name="birthdate" id="birthdate"
                           placeholder="Date de naissance"
                    >
                    <span class="invalid-feedback" id="birthdateError"></span>
                </div>
                <!-- PHONE -->
                <div class="form-group">
                    <label for="phone">Numéro de téléphone</label>
                    <input type="number" class="form-control" name="phone" id="phone"
                           placeholder="Numéro de téléphone"
                    >
                    <span class="invalid-feedback" id="phoneError"></span>
                </div>
                <!-- MAIL -->
                <div class="form-group">
                    <label for="mail">Adresse email</label>
                    <input type="email" class="form-control" name="mail" id="mail"
                           placeholder="Adresse email"
                    >
                    <span class="invalid-feedback" id="mailError"></span>
                </div>
                <!-- DATE -->
                <div class="form-group">
                    <label for="dateHour">Date du rendez-vous</label>
                    <div class="input-group date" id="dateHour" data-target-input="nearest">
                        <input type="text" class="form-control datetimepicker-input" data-target="#dateHour"
                               name="dateHour" id="dateHourInput">
                        <div class="input-group-append" data-target="#dateHour" data-toggle="datetimepicker">
                            <div class="input-group-text"><i class="fas fa-calendar-alt"></i></div>
                        </div>
                        <span class="invalid-feedback" id="dateHourInputError"></span>

                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <input type="button" id="submitForm" value="Ajouter le patient et le rendez-vous"
                               class="btn btn-success btn-block">
                    </div>
                </div>
            </form>

        </div>
    </div>
</div>
<script src="<?= URLROOT; ?>/js/appointments/dateHour.js"></script>
<script src="<?= URLROOT; ?>/js/patientAppointment/validations.js"></script>

<?php require APPROOT . '/views/inc/footer.php'; ?>
