<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo URLROOT; ?>/vendors/bootstrap/css/bootstrap.css" >
    <link rel="stylesheet" href="<?php echo URLROOT; ?>/vendors/bootstrap/css/tempusdominus.css" >
    <link rel="stylesheet" href="<?php echo URLROOT; ?>/css/style.css">
    <link rel="stylesheet" href="<?php echo URLROOT; ?>/vendors/font-awesome/css/all.css" >


    <!-- JS -->
    <script src="<?= URLROOT; ?>/vendors/font-awesome/js/all.js"></script>
    <script src="<?= URLROOT; ?>/vendors/jquery.js"></script>
    <script src="<?= URLROOT; ?>/vendors/moment.js"></script>
    <script src="<?= URLROOT; ?>/vendors/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?= URLROOT; ?>/vendors/bootstrap/js/tempusdominus.js"></script>
    <script src="<?= URLROOT; ?>/js/main.js"></script>

    <title><?php echo $data['pageTitle'] ?></title>
</head>
<body>
<?php require APPROOT . '/views/inc/navbar.php' ?>
<div class="container">


