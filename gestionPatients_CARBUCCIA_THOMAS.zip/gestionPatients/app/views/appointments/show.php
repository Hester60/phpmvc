<?php require APPROOT . '/views/inc/header.php'; ?>

    <div class="row py-5">
        <div class="col-md-10 mx-auto">
            <div class="card card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="card-title">Rendez-vous
                        avec <?= $data['appointment']->patientLastname . ' ' . $data['appointment']->patientFirstname ?></div>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#editModal">Modifier
                        le rendez-vous
                    </button>
                </div>
                <!-- Affichage des erreurs s'il y en a -->
                <?php if (isset($data['form_errors']) && count($data['form_errors']) > 0): ?>
                    <div class="alert alert-danger">
                        <div class="formErrors">
                            <div>Le rendez-vous n'a pas été modifié: </div>
                            <?php foreach ($data['form_errors'] as $error): ?>
                                - <?= $error ?><br>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif ?>

                <!-- Message en cas de succès -->
                <?php flash('edit_appointment_success'); ?>

                <ul class="list-group my-3">
                    <li class="list-group-item">Date du rendez-vous :
                        <strong><?= $data['appointment']->dateHour ?></strong></li>
                    <li class="list-group-item">Patient :
                        <strong><?= $data['appointment']->patientLastname . ' ' . $data['appointment']->patientFirstname ?></strong>
                    </li>
                </ul>
            </div>



        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editLabel">Modifier le rendez-vous</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">


                    <form class="form" id="appointmentForm" name="createAppointment"
                          action="<?php echo URLROOT; ?>/appointments/show/<?= $data['appointment']->id ?>"
                          method="POST">
                        <!-- DATE -->
                        <div class="form-group">
                            <div class="input-group date" id="dateHour" data-target-input="nearest">
                                <input type="text" class="form-control datetimepicker-input" data-target="#dateHour" name="dateHour" id="dateHourInput"  value="<?= $data['appointment']->dateHour ?>" >
                                <div class="input-group-append" data-target="#dateHour" data-toggle="datetimepicker">
                                    <div class="input-group-text"><i class="fas fa-calendar-alt"></i></div>
                                </div>
                                <span class="invalid-feedback" id="dateHourInputError"></span>

                            </div>

                        </div>
                        <!-- PATIENT -->
                        <div class="form-group">
                            <label for="idPatients">Patient</label>
                            <select class="form-control" id="idPatients" name="idPatients">
                                <option value="0" disabled>Choisissez un patient</option>
                                <?php foreach ($data['patients'] as $patient): ?>
                                    <option
                                        <?php if ($data['appointment']->patientId === $patient->id): ?>
                                            selected
                                        <?php endif ?>
                                        value="<?= $patient->id ?>"><?= $patient->lastname . ' ' . $patient->firstname ?></option>
                                <?php endforeach; ?>


                            </select>
                        </div>


                        <div class="row">
                            <div class="col">
                                <input type="button" id="submitForm" value="Enregistrer"
                                       class="btn btn-success btn-block">
                            </div>
                        </div>

                    </form>
                </div>

            </div>

        </div>
    </div>

    <script src="<?= URLROOT; ?>/js/appointments/validations.js"></script>
    <script src="<?= URLROOT; ?>/js/appointments/dateHour.js"></script>


<?php require APPROOT . '/views/inc/footer.php'; ?>