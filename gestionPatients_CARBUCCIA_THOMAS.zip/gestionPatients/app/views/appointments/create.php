<?php require APPROOT . '/views/inc/header.php'; ?>

    <div class="row py-5">
        <div class="col-md-10 mx-auto">
            <div class="card card-body">
                <div class="card-title">Ajouter un nouveau rendez-vous</div>

                <!-- Affichage des erreurs s'il y en a -->
                <?php if (isset($data['form_errors']) && count($data['form_errors']) > 0): ?>
                    <div class="alert alert-danger">
                        <div class="formErrors">
                            <?php foreach ($data['form_errors'] as $error): ?>
                                <?= $error ?><br>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif ?>


                <form class="form" id="appointmentForm" name="createAppointment" action=<?php echo URLROOT; ?>/appointments/create method="POST">
                    <!-- DATE -->
                    <div class="form-group">
                        <div class="input-group date" id="dateHour" data-target-input="nearest">
                            <input type="text" class="form-control datetimepicker-input" data-target="#dateHour" name="dateHour" id="dateHourInput" >
                            <div class="input-group-append" data-target="#dateHour" data-toggle="datetimepicker">
                                <div class="input-group-text"><i class="fas fa-calendar-alt"></i></div>
                            </div>
                            <span class="invalid-feedback" id="dateHourInputError"></span>

                        </div>
                    </div>

                    <!-- PATIENT -->
                    <div class="form-group">
                        <label for="idPatients">Patient</label>
                        <select class="form-control" id="idPatients" name="idPatients">
                            <option value="0" disabled >Choisissez un patient</option>
                            <?php foreach ($data['patients'] as $patient): ?>
                                <option value="<?= $patient->id ?>"><?= $patient->lastname . ' ' . $patient->firstname ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>


                    <div class="row">
                        <div class="col">
                            <input type="button" id="submitForm" value="Enregistrer" class="btn btn-success btn-block">
                        </div>
                    </div>
                    <hr class="divider">
                    <div class="row">
                        <div class="col">
                            <a href="<?php echo URLROOT; ?>/appointments" class="btn btn-dark btn-block">
                                Voir la liste des rendez-vous
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="<?= URLROOT; ?>/js/appointments/validations.js"></script>
    <script src="<?= URLROOT; ?>/js/appointments/dateHour.js"></script>



<?php require APPROOT . '/views/inc/footer.php'; ?>