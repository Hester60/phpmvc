<?php require APPROOT . '/views/inc/header.php'; ?>

    <div class="row py-5">
        <div class="col-md-10 mx-auto">
            <div class="card card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="card-title">Liste des rendez-vous</div>
                    <a href="<?php echo URLROOT; ?>/appointments/create" class="btn btn-primary">Nouveau rendez-vous</a>
                </div>


                <!-- Affichage des erreurs s'il y en a -->
                <?php if (isset($data['form_errors']) && count($data['form_errors']) > 0): ?>
                    <div class="alert alert-danger">
                        <div class="formErrors">
                            <?php foreach ($data['form_errors'] as $error): ?>
                                <?= $error ?><br>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif ?>

                <hr>
                <!-- Message en cas de succès -->
                <?php flash('delete_appointment_success'); ?>



                <?php if (count($data['appointments']) <= 0): ?>
                    <span>Aucun rendez-vous</span>
                <?php else: ?>


                    <!-- TABLE -->
                    <table class="table mt-4">
                        <thead>
                        <tr>
                            <th scope="col">Date</th>
                            <th scope="col">Patient</th>
                            <th scope="col">Actions</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php foreach ($data['appointments'] as $appointment): ?>
                            <tr>
                                <td><?= $appointment->dateHour ?></td>
                                <td><?= $appointment->patientLastname . ' ' . $appointment->patientFirstname ?></td>
                                <td class="d-flex">

                                    <a href="<?= URLROOT ?>/appointments/show/<?= $appointment->id ?>"
                                       class="btn btn-primary active"
                                       title="Voir le rendez-vous">
                                        <i class="far fa-eye"></i>
                                    </a>
                                    <form action="<?= URLROOT ?>/appointments/delete/<?= $appointment->id ?>"
                                          method="POST">
                                        <button type="submit" class="btn btn-danger ml-1">
                                            <i class="fas fa-trash-alt "></i>
                                        </button>
                                    </form>

                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif ?>
            </div>
        </div>
    </div>

<?php require APPROOT . '/views/inc/footer.php'; ?>