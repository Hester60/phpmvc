<?php require APPROOT . '/views/inc/header.php'; ?>

<div class="row py-5">
    <div class="col-md-10 mx-auto">
        <div class="card card-body">
            <div class="d-flex justify-content-between">
                <div class="card-title ">
                    <?= $data['pageTitle'] ?>
                </div>
                <div>
                    <a href="<?= URLROOT ?>/patients/create" class="btn btn-primary">Nouveau patient</a>
                </div>
            </div>
            <hr>
            <!-- Formulaire de recherche -->
            <form class="form-inline py-3" action="<?= URLROOT ?>/patients" method="POST">
                <div class="form-group mb-2">
                    <input type="text" class="form-control" id="search" name="search" placeholder="Nom de famille"
                           value="<?= $data['searchTerms'] ?>"

                    >
                </div>
                <button type="submit" id="submitSearch" class="btn btn-primary mb-2 ml-2" disabled>Rechercher</button>
            </form>


            <?= flash('delete_patient_success'); ?>
            <?= flash('create_patient_success'); ?>

            <?php if (count($data['patients']) <= 0): ?>
                <span>Aucun résultat</span>
            <?php else: ?>


                <!-- Table -->
                <div class=" table-responsive">
                    <table class="table table-patient">
                        <thead>
                        <tr>

                            <th scope="col">Nom</th>
                            <th scope="col">Prénom</th>
                            <th scope="col">Date de naissance</th>
                            <th scope="col">Téléphone</th>
                            <th scope="col">Email</th>
                            <th scope="col">Actions</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php foreach ($data['patients'] as $patient): ?>
                            <tr>

                                <td><?= $patient->lastname ?></td>
                                <td><?= $patient->firstname ?></td>
                                <td><?= $patient->birthdate ?></td>
                                <td><?= $patient->phone ?></td>
                                <td><?= $patient->mail ?></td>
                                <td class="d-flex">

                                    <a href="<?= URLROOT ?>/patients/show/<?= $patient->id ?>"
                                       class="btn btn-primary active"
                                       title="Voir le profil">
                                        <i class="far fa-eye"></i>
                                    </a>
                                    <form action="<?= URLROOT ?>/patients/delete/<?= $patient->id ?>" method="POST">
                                        <button type="submit" class="btn btn-danger ml-1">
                                            <i class="fas fa-trash-alt "></i>
                                        </button>
                                    </form>

                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>

                    </table>
                </div>
                <div class="pagination mx-auto">
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <a
                                href="<?= URLROOT ?>/patients?<?php !empty($data['searchTerms']) ? '=lastname' . $data['searchTerms'] . '&' : '' ?><?= 'page=' . $data['previousPage'] ?>"
                                class="btn btn-secondary <?= $data['previousPage'] == '-1' ? 'disabled' : '' ?>">

                            <i class="fas fa-chevron-left"></i>
                        </a>
                        <button type="button" class="btn btn-secondary" disabled><?= $data['currentPage'] ?></button>
                        <a
                                href="<?= URLROOT ?>/patients?<?php !empty($data['searchTerms']) ? '=lastname' . $data['searchTerms'] : '' ?><?= 'page=' . $data['nextPage'] ?>"
                                class="btn btn-secondary <?= $data['currentPage'] == $data['maxPage'] ? 'disabled' : '' ?>""><i
                                class="fas fa-chevron-right"></i></a>
                    </div>
                </div>

            <?php endif ?>
        </div>

    </div>
</div>

<script src="<?= URLROOT; ?>/js/search/validation.js"></script>


<?php require APPROOT . '/views/inc/footer.php'; ?>
