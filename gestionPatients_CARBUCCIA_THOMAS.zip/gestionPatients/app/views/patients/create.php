<?php require APPROOT . '/views/inc/header.php'; ?>

    <div class="row py-5">
        <div class="col-md-10 mx-auto">
            <div class="card card-body">
                <div class="card-title">Ajouter un nouveau patient</div>

                <!-- Affichage des erreurs s'il y en a -->
                <?php if (isset($data['form_errors']) && count($data['form_errors']) > 0): ?>
                    <div class="alert alert-danger">
                        <div class="formErrors">
                            <?php foreach ($data['form_errors'] as $error): ?>
                                - <?= $error ?><br>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif ?>

                <form class="form" id="patientForm" name="createPatient" action=<?php echo URLROOT; ?>/patients/create method="POST">
                    <!-- LASTNAME -->
                    <div class="form-group">
                        <label for="lastname">Nom</label>
                        <input type="text" class="form-control" name="lastname" id="lastname"
                               placeholder="Nom de famille" >
                        <span class="invalid-feedback" id="lastnameError"></span>
                    </div>
                    <!-- FIRSTNAME -->
                    <div class="form-group">
                        <label for="firstname">Prénom</label>
                        <input type="text" class="form-control" name="firstname"
                               id="firstname" placeholder="Prénom"
                        >
                        <span class="invalid-feedback" id="firstnameError"></span>
                    </div>
                    <!-- BIRTHDATE -->
                    <div class="form-group">
                        <label for="birthdate">Date de naissance</label>
                        <input type="date" class="form-control" name="birthdate" id="birthdate"
                               placeholder="Date de naissance"
                        >
                        <span class="invalid-feedback" id="birthdateError"></span>
                    </div>
                    <!-- PHONE -->
                    <div class="form-group">
                        <label for="phone">Numéro de téléphone</label>
                        <input type="number" class="form-control" name="phone" id="phone"
                               placeholder="Numéro de téléphone"
                        >
                        <span class="invalid-feedback" id="phoneError"></span>
                    </div>
                    <!-- MAIL -->
                    <div class="form-group">
                        <label for="mail">Adresse email</label>
                        <input type="email" class="form-control" name="mail" id="mail"
                               placeholder="Adresse email"
                        >
                        <span class="invalid-feedback" id="mailError"></span>
                    </div>
                    <div class="row">
                        <div class="col">
                            <input type="button" id="submitForm" value="Ajouter" class="btn btn-success btn-block">
                        </div>
                    </div>
                    <hr class="divider">
                    <div class="row">
                        <div class="col">
                            <a href="<?php echo URLROOT; ?>/patients" class="btn btn-dark btn-block">
                                Voir la liste des patients
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="<?= URLROOT; ?>/js/patients/validations.js"></script>

<?php require APPROOT . '/views/inc/footer.php'; ?>