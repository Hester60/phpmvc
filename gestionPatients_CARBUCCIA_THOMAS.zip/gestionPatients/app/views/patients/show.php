<?php require APPROOT . '/views/inc/header.php'; ?>

    <div class="row py-5">
        <div class="col-md-10 mx-auto">
            <div class="card card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="card-title"><?= 'Profil de ' . $data['patient']->lastname . ' ' . $data['patient']->firstname ?></div>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#editModal">Modifier
                        le patient
                    </button>
                </div>
                <!-- Message en cas de succès -->
                <?php flash('edit_patient_success'); ?>
                <?php flash('create_patientAppointment_success'); ?>

                <!-- Affichage des erreurs s'il y en a -->
                <?php if (isset($data['form_errors']) && count($data['form_errors']) > 0): ?>
                    <div class="alert alert-danger">
                        <div class="formErrors">
                            <div>Le patient n'a pas été modifié : </div>
                            <?php foreach ($data['form_errors'] as $error): ?>
                                - <?= $error ?><br>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif ?>

                <ul class="list-group my-3">
                    <li class="list-group-item">Nom de famille : <strong><?= $data['patient']->lastname ?></strong></li>
                    <li class="list-group-item">Prénom : <strong><?= $data['patient']->firstname ?></strong></li>
                    <li class="list-group-item">Date de naissance : <strong><?= $data['patient']->birthdate ?></strong>
                    </li>
                    <li class="list-group-item">Téléphone : <strong><?= $data['patient']->phone ?></strong></li>
                    <li class="list-group-item">Email : <strong><?= $data['patient']->mail ?></strong></li>

                </ul>
            </div>

            <div class="card card-body mt-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="card-title">Rendez-vous de <?= $data['patient']->lastname . ' ' . $data['patient']->firstname ?></div>
                </div>

                <?php if (count($data['appointments']) <= 0): ?>
                    <span><?= $data['patient']->lastname . ' ' . $data['patient']->firstname ?> n'a pas de rendez-vous.</span>
                <?php else: ?>


                <!-- TABLE -->
                <table class="table mt-4">
                    <thead>
                    <tr>
                        <th scope="col">Date</th>

                        <th scope="col">Actions</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php foreach ($data['appointments'] as $appointment): ?>
                        <tr>
                            <td><?= $appointment->dateHour ?></td>
                            <td>
                                <a href="<?= URLROOT ?>/appointments/show/<?= $appointment->id ?>"
                                   class="btn btn-primary active"
                                   title="Voir le rendez-vous">
                                    <i class="far fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif ?>
            </div>


        </div>
    </div>


    <!-- Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editLabel">Modifier le profil de <?= $data['patient']->lastname . ' ' . $data['patient']->firstname ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <form class="form" id="patientForm" name="editPatient" action="<?php echo URLROOT; ?>/patients/show/<?= $data['patient']->id ?>"
                          method="POST">
                        <!-- LASTNAME -->
                        <div class="form-group">
                            <label for="lastname">Nom</label>
                            <input type="text" class="form-control" name="lastname" id="lastname"
                                   placeholder="Nom de famille"
                                   value='<?= $data['patient']->lastname ?>'
                            >
                            <span class="invalid-feedback" id="lastnameError"></span>
                        </div>
                        <!-- FIRSTNAME -->
                        <div class="form-group">
                            <label for="firstname">Prénom</label>
                            <input type="text" class="form-control" name="firstname"
                                   id="firstname" placeholder="Prénom"
                                   value='<?= $data['patient']->firstname ?>'
                            >
                            <span class="invalid-feedback" id="firstnameError"></span>
                        </div>
                        <!-- BIRTHDATE -->
                        <div class="form-group">
                            <label for="birthdate">Date de naissance</label>
                            <input type="date" class="form-control" name="birthdate" id="birthdate"
                                   placeholder="Date de naissance"
                                   value='<?= format_date_FrToMySQL($data['patient']->birthdate) ?>'
                            >
                            <span class="invalid-feedback" id="birthdateError"></span>
                        </div>
                        <!-- PHONE -->
                        <div class="form-group">
                            <label for="phone">Numéro de téléphone</label>
                            <input type="tel" class="form-control" name="phone" id="phone"
                                   placeholder="Numéro de téléphone"
                                   value='<?= $data['patient']->phone ?>'
                            >
                            <span class="invalid-feedback" id="phoneError"></span>
                        </div>
                        <!-- MAIL -->
                        <div class="form-group">
                            <label for="mail">Adresse email</label>
                            <input type="email" class="form-control" name="mail" id="mail"
                                   placeholder="Adresse email"
                                   value='<?= $data['patient']->mail ?>'
                            >
                            <span class="invalid-feedback" id="mailError"></span>
                        </div>
                        <div class="row">
                            <div class="col">
                                <input type="button" id="submitForm" value="Modifier le patient" class="btn btn-success btn-block">
                            </div>
                        </div>

                    </form>
                </div>

            </div>

        </div>
    </div>
    <script src="<?= URLROOT; ?>/js/patients/validations.js"></script>

<?php require APPROOT . '/views/inc/footer.php'; ?>